# -*- coding: utf-8 -*-
import os
import sys
import random
import base64

from download_center.new_spider.downloader.downloader import SpiderRequest
from download_center.new_spider.spider.basespider import BaseSpider
from download_center.util.util_log import UtilLogger

# 线上测试
PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(PROJECT_PATH)
sys.path.append(os.path.join(PROJECT_PATH, 'demo'))

import time
import base64

reload(sys)
sys.setdefaultencoding('utf8')


class DemoSpider(BaseSpider):
    def __init__(self, remote=True):
        super(DemoSpider, self).__init__(remote=remote)
        self.log = UtilLogger('DemoSpider', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'log_demo_spider'))
        self.seed_url = "https://www.baidu.com/s?wd=%s"

    def get_user_password(self):
        return 'test', 'test'

    def start_requests(self):
        try:
            url = "http://www.baidu.com"
            urls = [{'url': url, 'type': 1, "test": "test"}]
            ua = random.choice(self.pc_user_agents)
            request = SpiderRequest(headers={"User-Agent": ua}, urls=urls)
            self.sending_queue.put(request)
        except Exception, e:
            self.log.error('获取初始请求出错:%s' % str(e))

    def get_stores(self):
        # 存储器
        stores = list()
        return stores

    def deal_response_results_status(self, task_status, url, result, request):
        if task_status == '2':
            print result["result"]
            print("result end")
        else:
            self.log.info('抓取失败:%s' % url)

    def to_store_results(self,  results, stores):
        """
        结果存储按需使用
        :return:
        """
        pass


def main():
    spider = DemoSpider()
    # spider.run(1, 1, 1, 1, record_log=True)   # 测试
    spider.run(spider_count=1000, record_log=True)
    # spider.run(record_log=True)               # error


if __name__ == '__main__':
    main()

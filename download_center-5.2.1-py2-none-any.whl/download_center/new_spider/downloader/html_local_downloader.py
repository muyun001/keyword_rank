# -*- coding: utf8 -*-
import urllib2
import traceback
import hashlib
import sys
import urllib
import pymysql
import gzip
import json
import StringIO
reload(sys)
sys.setdefaultencoding('utf8')


def util_md5(s):
    m = hashlib.md5()
    m.update(s)
    return m.hexdigest()


class HtmlLocalDownloader(object):
    """
    html下载器
    """

    def __init__(self, set_mode='db', get_mode='db', store_type=5):     # 兼容 保留
        # super(HtmlLocalDownloader, self).__init__()
        self.user_id = 0

    def downloader_set_param(self, request, store_type=5):
        url_type = None
        new_urls = list()
        for url in request.urls:
            if url_type is None:
                url_type = url['type']
            new_url = dict()
            new_url['url'] = url['url']
            if 'unique_key' in url.keys():
                md5 = util_md5(pymysql.escape_string(url['url']) + str(url['unique_key']))
            else:
                md5 = util_md5(pymysql.escape_string(url['url']))
            new_url['md5'] = md5
            new_urls.append(new_url)

            url['unique_md5'] = md5
        if len(new_urls) > 0:
            params = {
                'user_id': self.user_id,
                'url_type': url_type,
                'header': request.headers,
                'redirect': 0,
                'priority': 2,
                'single': 0,
                'store_type': store_type,
                'urls': new_urls,
                'concurrent_num': 0,     # 默认
                'conf_district_id': 0
            }
            if 'redirect' in request.config and request.config['redirect'] == 1:
                params['redirect'] = request.config['redirect']
            if 'post_data' in request.config:
                params['post_data'] = request.config['post_data']
            return params
        return None

    def set(self, request):
        try:
            results = dict()
            param = self.downloader_set_param(request)
            for url in param['urls']:
                results[url['md5']] = 1
            return results
        except Exception:
            print(traceback.format_exc())
            return 0

    @staticmethod
    def encoding(data):
        types = ['utf-8', 'gb2312', 'gbk', 'gb18030', 'iso-8859-1']
        for t in types:
            try:
                return data.decode(t)
            except Exception, e:
                pass
        return None

    def get(self, request):
        param = self.downloader_set_param(request)
        if param is None:
            return 0
        urls = param['urls']
        if len(urls) > 0:
            try:
                results = dict()
                url_type = param['url_type']
                headers = param['header']
                data = None
                if 'post_data' in param:
                    # data = param['post_data']
                    data = urllib.urlencode(param['post_data'])
                opener = urllib2.build_opener()
                if 'redirect' in param and str(param['redirect']) == '0':
                    redirect_handler = UnRedirectHandler()
                    opener = urllib2.build_opener(redirect_handler)
                for url in urls:
                    request = urllib2.Request(url['url'], data=data, headers=headers)
                    result = {"status": "3", "result": "", "header": ""}
                    for i in range(0, 2):
                        try:
                            response = opener.open(request, timeout=30)
                            header = response.info()
                            body = response.read()
                            if ('Content-Encoding' in header and header['Content-Encoding']) or \
                                    ('content-encoding' in header and header['content-encoding']):

                                d = StringIO.StringIO(body)
                                gz = gzip.GzipFile(fileobj=d)
                                body = gz.read()
                                gz.close()
                            body = self.encoding(body)
                            if body is not None:
                                result["result"] = body
                                result["status"] = "2"
                                result["header"] = str(header)
                                break
                        except Exception, e:
                            traceback.print_exc()
                    results[url['md5']] = result

                del opener
                del request
                return results
            except Exception:
                print(traceback.format_exc())
        return 0


class UnRedirectHandler(urllib2.HTTPRedirectHandler):

    def __init__(self):
        pass

    def http_error_302(self, req, fp, code, msg, headers):
        if 'location' in headers:
            newurl = headers.getheaders('location')[0]
            return newurl, code, headers
        pass

    http_error_301 = http_error_303 = http_error_307 = http_error_302
